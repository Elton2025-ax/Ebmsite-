function listUsers() {
    console.log(users);
}

function deleteUser(username) {
    users = users.filter(u => u.username !== username);
}