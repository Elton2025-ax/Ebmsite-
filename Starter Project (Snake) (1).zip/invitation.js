function updateBackground() {
    let type = document.getElementById("type").value;
    let preview = document.getElementById("preview");

    if (type === "Mariage") preview.className = "mariage-bg";
    else if (type === "Anniversaire") preview.className = "anniversaire-bg";
    else preview.className = "entreprise-bg";
}

function generateInvitation() {
    let marie1 = document.getElementById("marie1").value;
    let marie2 = document.getElementById("marie2").value;
    let nomInvite = document.getElementById("nomInvite").value;
    let message = `${marie1} et ${marie2} sont heureux de vous inviter à célébrer leur mariage !`;

    document.getElementById("messageInvitation").innerText = message;
}

function generatePDF() {
    let doc = new jsPDF();
    doc.text(document.getElementById("messageInvitation").innerText, 20, 30);
    doc.save("invitation.pdf");
}

function shareWhatsApp() {
    let text = document.getElementById("messageInvitation").innerText;
    let url = `https://api.whatsapp.com/send?text=${encodeURIComponent(text)}`;
    window.open(url, "_blank");
}

function shareEmail() {
    let subject = "Votre Invitation";
    let body = document.getElementById("messageInvitation").innerText;
    let mailtoLink = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    window.open(mailtoLink, "_blank");
}