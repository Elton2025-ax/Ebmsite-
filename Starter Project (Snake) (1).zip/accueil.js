const menuToggle = document.querySelector('.menu-toggle');
const menu = document.querySelector('.menu');
const icon = menuToggle.querySelector('i');

menuToggle.addEventListener('click', () => {
    menu.classList.toggle('active');
    icon.classList.toggle('fa-bars');
    icon.classList.toggle('fa-times');
});