// form.js

const openBtn = document.getElementById('openModal');
const loginModal = document.getElementById('loginModal');
const closeBtn = document.querySelector('.modal .close');
const loginUserBtn = document.getElementById('loginUser');
const registerUserBtn = document.getElementById('registerUser');
const usernameInput = document.getElementById('username');
const passwordInput = document.getElementById('password');
const loginMsg = document.getElementById('loginMsg');
const profileSection = document.getElementById('profileSection');
const profileName = document.getElementById('profileName');
const profilePic = document.getElementById('profileImage'); // Correction du nom
const logoutBtn = document.getElementById('logoutBtn');
const adminSection = document.getElementById('adminSection');
const userList = document.getElementById('userList');
const profilePicInput = document.getElementById('profileImageInput'); // Correction du nom
const resetAdminBtn = document.getElementById('resetAdminBtn');
const logList = document.getElementById('logList');

// Chargement des utilisateurs depuis localStorage
function loadUsers() {
    const users = localStorage.getItem('users');
    return users ? JSON.parse(users) : [];
}

// Sauvegarde des utilisateurs dans localStorage
function saveUsers(users) {
    localStorage.setItem('users', JSON.stringify(users));
}

// Affichage du profil utilisateur
function showProfile(username) {
    const users = loadUsers();
    const user = users.find(u => u.username === username);
    profileName.textContent = username;
    profileSection.style.display = 'block';
    openBtn.style.display = 'none';

    if (user && user.profilePic) {
        profilePic.src = user.profilePic;
        profilePic.style.display = 'block';
    } else {
        profilePic.src = 'https://via.placeholder.com/100';
        profilePic.style.display = 'block';
    }

    if (username === 'admin') {
        showAdminPanel();
    }
}

// Masquer le profil utilisateur
function hideProfile() {
    profileSection.style.display = 'none';
    openBtn.style.display = 'inline-block';
    adminSection.style.display = 'none';
}

// Affichage du panneau admin
function showAdminPanel() {
    const users = loadUsers();
    userList.innerHTML = '';

    users.forEach((user, index) => {
        const li = document.createElement('li');
        li.innerHTML = `<i class="fa fa-user"></i> ${user.username}`;

        if (user.username !== 'admin') {
            const delBtn = document.createElement('button');
            delBtn.innerHTML = '<i class="fa fa-trash"></i>';
            delBtn.classList.add('admin-btn');

            delBtn.addEventListener('click', () => {
                if (confirm(`Supprimer l’utilisateur "${user.username}" ?`)) {
                    users.splice(index, 1);
                    saveUsers(users);
                    showAdminPanel();
                }
            });

            li.appendChild(delBtn);
        }

        userList.appendChild(li);
    });

    adminSection.style.display = 'block';
}

// Ajout de l'événement sur le bouton Enregistrer
registerUserBtn.addEventListener('click', () => {
    const username = usernameInput.value.trim();
    const password = passwordInput.value.trim();
    let users = loadUsers();

    console.log(`Pseudo: ${username}, Mot de passe: ${password}`); // Debugging

    if (!username || !password) {
        loginMsg.style.color = 'red';
        loginMsg.textContent = 'Remplissez tous les champs.';
        console.log("Message d'erreur affiché : Champs vides"); // Debugging
        return;
    }

    if (users.find(u => u.username === username)) {
        loginMsg.style.color = 'red';
        loginMsg.textContent = 'Ce pseudo existe déjà.';
    } else {
        users.push({ username, password, profilePic: '' });
        saveUsers(users);
        localStorage.setItem('currentUser', username);
        loginMsg.style.color = 'green';
        loginMsg.textContent = `Compte créé et connecté, ${username} !`;
        showProfile(username);
        setTimeout(() => loginModal.style.display = 'none', 1000);
    }
});

// Ajout de l'événement pour la connexion utilisateur
loginUserBtn.addEventListener('click', () => {
    const username = usernameInput.value.trim();
    const password = passwordInput.value.trim();
    const users = loadUsers();

    const user = users.find(u => u.username === username && u.password === password);
    if (user) {
        localStorage.setItem('currentUser', username);
        loginMsg.style.color = 'green';
        loginMsg.textContent = `Bienvenue, ${username} !`;
        showProfile(username);
        setTimeout(() => loginModal.style.display = 'none', 1000);
    } else {
        loginMsg.style.color = 'red';
        loginMsg.textContent = 'Identifiants incorrects.';
    }
});

// Ajout de l'événement pour la mise à jour de la photo de profil
profilePicInput.addEventListener('change', (event) => {
    const file = event.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = () => {
            const users = loadUsers();
            const currentUser = localStorage.getItem('currentUser');
            const user = users.find(u => u.username === currentUser);
            if (user) {
                user.profilePic = reader.result;
                saveUsers(users);
                profilePic.src = reader.result;
                profilePic.style.display = 'block';
            }
        };
        reader.readAsDataURL(file);
    }
});

// Ajout de l'événement pour la déconnexion
logoutBtn.addEventListener('click', () => {
    localStorage.removeItem('currentUser');
    hideProfile();
});

// Affichage automatique du profil si un utilisateur est connecté
document.addEventListener('DOMContentLoaded', () => {
    let users = loadUsers();
    if (!users.find(u => u.username === 'admin')) {
        users.push({ username: 'admin', password: 'admin123', profilePic: '' });
        saveUsers(users);
    }

    const currentUser = localStorage.getItem('currentUser');
    if (currentUser) {
        showProfile(currentUser);
    }
});

// Ajout de l'événement pour ouvrir la modale de connexion
openBtn.addEventListener('click', () => {
    loginModal.style.display = 'block';
});

// Ajout de l'événement pour fermer la modale
closeBtn.addEventListener('click', () => {
    loginModal.style.display = 'none';
    loginMsg.textContent = '';
});

// Ajout de l'événement pour fermer la modale en cliquant à l'extérieur
window.addEventListener('click', (e) => {
    if (e.target === loginModal) {
        loginModal.style.display = 'none';
        loginMsg.textContent = '';
    }
});

// Ajout d'un message de confirmation avec animation
function showMessage(msg, color) {
    let existingMsg = document.getElementById('pageMessage');
    if (!existingMsg) {
        existingMsg = document.createElement('div');
        existingMsg.id = 'pageMessage';
        existingMsg.style.position = 'fixed';
        existingMsg.style.top = '20px';
        existingMsg.style.right = '20px';
        existingMsg.style.padding = '10px 20px';
        existingMsg.style.backgroundColor = color || 'green';
        existingMsg.style.color = 'white';
        existingMsg.style.borderRadius = '5px';
        existingMsg.style.zIndex = '2000';
        existingMsg.style.opacity = '1';
        existingMsg.style.transition = 'opacity 0.5s ease-in-out';
        document.body.appendChild(existingMsg);
    }
    existingMsg.textContent = msg;

    setTimeout(() => {
        existingMsg.style.opacity = '0';
        setTimeout(() => existingMsg.remove(), 500);
    }, 3000);
}

console.log("Script chargé avec succès !");


function sendEmail() {
    emailjs.send("service_id", "template_id", {
        message: document.getElementById("adminMessage").value,
        to_email: "utilisateur@example.com"
    }).then(() => {
        alert("Email envoyé !");
    }).catch((error) => {
        console.error("Erreur d'envoi :", error);
    });
}

emailjs.init("ton_user_id"); // Remplace avec ton User ID EmailJS

document.getElementById("emailForm").addEventListener("submit", function(event) {
    event.preventDefault();
    
    emailjs.send("ton_service_id", "ton_template_id", {
        email: document.getElementById("email").value,
        message: document.getElementById("message").value
    })
    .then(() => {
        document.getElementById("emailStatus").textContent = "Email envoyé avec succès !";
    })
    .catch((error) => {
        document.getElementById("emailStatus").textContent = "Erreur d'envoi.";
        console.error("Erreur:", error);
    });
});