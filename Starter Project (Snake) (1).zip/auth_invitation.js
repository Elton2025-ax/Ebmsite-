let users = [];

function register(username, password, role = "user") {
    users.push({ username, password, role });
}

function login(username, password) {
    let user = users.find(u => u.username === username && u.password === password);
    return user ? user.role : null;
}