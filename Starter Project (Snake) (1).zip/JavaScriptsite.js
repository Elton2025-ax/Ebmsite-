const menuToggle = document.querySelector('.menu-toggle');
const menu = document.querySelector('.menu');
const icon = menuToggle.querySelector('i');

menuToggle.addEventListener('click', () => {
    menu.classList.toggle('active');
    icon.classList.toggle('fa-bars');
    icon.classList.toggle('fa-times');
});

// Connexion modal
const loginBtn = document.getElementById('loginBtn');
const loginModal = document.getElementById('loginModal');
const closeBtn = document.querySelector('.modal .close');
const saveBtn = document.getElementById('saveBtn');
const usernameInput = document.getElementById('username');
const welcomeMsg = document.getElementById('welcomeMsg');

loginBtn.addEventListener('click', () => {
    loginModal.style.display = 'flex';
});

closeBtn.addEventListener('click', () => {
    loginModal.style.display = 'none';
});

window.addEventListener('click', (e) => {
    if (e.target === loginModal) {
        loginModal.style.display = 'none';
    }
});

saveBtn.addEventListener('click', () => {
    const username = usernameInput.value.trim();
    if (username) {
        localStorage.setItem('username', username);
        welcomeMsg.textContent = `Bienvenue, ${username} !`;
    }
});

// Affiche le pseudo si déjà enregistré
document.addEventListener('DOMContentLoaded', () => {
    const savedUser = localStorage.getItem('username');
    if (savedUser) {
        loginBtn.textContent = `Bonjour, ${savedUser}`;
    }
});


